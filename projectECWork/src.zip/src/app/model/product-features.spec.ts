import { ProductFeatures } from './product-features';

describe('ProductFeatures', () => {
  it('should create an instance', () => {
    expect(new ProductFeatures()).toBeTruthy();
  });
});
