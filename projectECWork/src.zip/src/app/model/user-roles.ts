export class UserRoles {


    public static useroptions:Array<any>=[
        {
            admin:[
                {label:'addEmployee',path:'addEmployee'},
                {label:'viewEmployee',path:'viewEmployee'},
                {label:'addDealer',path:'addDealer'},
                {label:'viewDealer',path:'viewDealer'}
               ],

           inventory:[

                       {label:'addProduct',path:'addProduct'},
                        {label:'viewProduct',path:'viewProduct'},
                     ]
       }
    ]
}




