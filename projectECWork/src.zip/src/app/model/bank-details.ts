export class BankDetails {

    bankAccountNumber:number;
    bankName:string;
    branchName:string;
    ifscNumber:string;
    cardNumber:number;

}
