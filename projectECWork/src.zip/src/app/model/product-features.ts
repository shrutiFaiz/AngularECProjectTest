export class ProductFeatures {

    featureId:number;
    featureName:string;
    featureValue:string;
}
