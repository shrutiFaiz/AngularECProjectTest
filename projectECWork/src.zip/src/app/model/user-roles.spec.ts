import { UserRoles } from './user-roles';

describe('UserRoles', () => {
  it('should create an instance', () => {
    expect(new UserRoles()).toBeTruthy();
  });
});
