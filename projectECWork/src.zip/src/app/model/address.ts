export class Address {

    addressId:number;
    areaName:string;
    cityName:string;
    districtName:string;
    landMark:string;
    stateName:string;
    pinCodeNumber:number;

}
