import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerViewpageComponent } from './customer-viewpage/customer-viewpage.component';

const routes: Routes = [
  {
    path:'',component:CustomerViewpageComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerRoutingModule { }
